﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Appmedica.Clases
{
    internal class OpenFdaInfo
    {
        [JsonPropertyName("brand_name")]
        public string[] BrandName { get; set; }
    }
}
