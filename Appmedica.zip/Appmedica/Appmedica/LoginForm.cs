﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appmedica
{
    public partial class LoginForm : Form
    {


        public LoginForm()
        {
            InitializeComponent();


        }
        private readonly Dictionary<string, string> users = new Dictionary<string, string>
        {
            { "admin", "1234" },
            { "user", "abcd" }
        };

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (users.ContainsKey(txtUser.Text) && users[txtUser.Text] == txtPass.Text)
            {


                var mainForm = new Tusalud();
                mainForm.ShowDialog();

            }
            else
            {
                lblMessage.Text = "Usuario o contraseña incorrectos";
            }
        }
        private void lblUser_Click(object sender, EventArgs e)
        {

        }
        private void LoginForm_Load(object sender, EventArgs e)
        {
            // Mostrar el mensaje de aviso médico con botones Sí/No (que funcionan como Acepto/No acepto)
            DialogResult resultado = MessageBox.Show(
                "AVISO IMPORTANTE\n\n" +
                "La información proporcionada en esta aplicación es meramente informativa y educativa. " +
                "Todo contenido médico mostrado debe considerarse como referencia general y no como " +
                "diagnóstico o recomendación profesional. Los resultados, sugerencias y análisis presentados " +
                "son aproximados y no sustituyen la consulta con un profesional de la salud calificado.\n\n" +
                "CONSULTE SIEMPRE CON SU MÉDICO antes de iniciar cualquier tratamiento, cambiar su régimen " +
                "alimenticio o consumir cualquier medicamento o suplemento.\n\n" +
                "Esta aplicación no se hace responsable por decisiones tomadas basadas únicamente en la información aquí presentada.",
                "Aviso Médico Importante",
                MessageBoxButtons.YesNo,  // Muestra botones Sí (Acepto) y No (No acepto)
                MessageBoxIcon.Warning    // Icono de advertencia
            );

            // Verificar la respuesta del usuario
            if (resultado == DialogResult.No)
            {
                // Si el usuario no acepta, cerrar la aplicación
                Application.Exit();
            }
            // Si acepta (DialogResult.Yes), la aplicación continúa normalmente
        }
        

        private void txtUser_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPass_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblPass_Click(object sender, EventArgs e)
        {

        }

        private void lblMessage_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


            var mainForm = new AskForm();
            mainForm.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {



            var mainForm = new Emergencias();
            mainForm.ShowDialog();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
