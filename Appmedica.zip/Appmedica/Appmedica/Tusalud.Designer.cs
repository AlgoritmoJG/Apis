﻿namespace Appmedica
{
    partial class Tusalud
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tusalud));
            txtSymptom = new TextBox();
            btnSearch = new Button();
            lblStatus = new Label();
            dgvResults = new DataGridView();
            drugName = new DataGridViewTextBoxColumn();
            description = new DataGridViewTextBoxColumn();
            pictureBox1 = new PictureBox();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvResults).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // txtSymptom
            // 
            txtSymptom.Location = new Point(12, 44);
            txtSymptom.Name = "txtSymptom";
            txtSymptom.Size = new Size(230, 27);
            txtSymptom.TabIndex = 0;
            txtSymptom.TextChanged += txtSymptom_TextChanged;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(55, 77);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(133, 70);
            btnSearch.TabIndex = 1;
            btnSearch.Text = "Ingresa tu sintoma";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(390, 24);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(50, 20);
            lblStatus.TabIndex = 2;
            lblStatus.Text = "label1";
            // 
            // dgvResults
            // 
            dgvResults.AllowUserToAddRows = false;
            dgvResults.AllowUserToDeleteRows = false;
            dgvResults.BackgroundColor = Color.LightGray;
            dgvResults.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvResults.Columns.AddRange(new DataGridViewColumn[] { drugName, description });
            dgvResults.Location = new Point(285, 24);
            dgvResults.Name = "dgvResults";
            dgvResults.ReadOnly = true;
            dgvResults.RowHeadersWidth = 51;
            dgvResults.Size = new Size(685, 488);
            dgvResults.TabIndex = 3;
            dgvResults.CellContentClick += dgvResults_CellContentClick;
            // 
            // drugName
            // 
            drugName.HeaderText = "Nombre Medicamento";
            drugName.MinimumWidth = 6;
            drugName.Name = "drugName";
            drugName.ReadOnly = true;
            drugName.Width = 125;
            // 
            // description
            // 
            description.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            description.HeaderText = "Descripcion";
            description.MinimumWidth = 6;
            description.Name = "description";
            description.ReadOnly = true;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(39, 168);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(240, 271);
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(192, 255, 255);
            button1.Location = new Point(58, 460);
            button1.Name = "button1";
            button1.Size = new Size(150, 55);
            button1.TabIndex = 5;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Tusalud
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(982, 554);
            Controls.Add(button1);
            Controls.Add(pictureBox1);
            Controls.Add(dgvResults);
            Controls.Add(lblStatus);
            Controls.Add(btnSearch);
            Controls.Add(txtSymptom);
            Name = "Tusalud";
            Text = "Tusalud";
            Load += Tusalud_Load;
            ((System.ComponentModel.ISupportInitialize)dgvResults).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtSymptom;
        private Button btnSearch;
        private Label lblStatus;
        private DataGridView dgvResults;
        private DataGridViewTextBoxColumn drugName;
        private DataGridViewTextBoxColumn description;
        private PictureBox pictureBox1;
        private Button button1;
    }
}