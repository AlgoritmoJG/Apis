﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appmedica
{
    public partial class Tusalud : Form
    {
        public Tusalud()
        {
            InitializeComponent();
            // Configurar DataGridView solo si no está configurado en diseñador
            if (dgvResults.Columns.Count == 0)
            {
                dgvResults.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dgvResults.ReadOnly = true;
                dgvResults.AllowUserToAddRows = false;
                dgvResults.AllowUserToDeleteRows = false;
                dgvResults.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

                dgvResults.Columns.Add("drugName", "Nombre del Medicamento");
                dgvResults.Columns.Add("description", "Descripción");
            }
        }


        private void txtSymptom_TextChanged(object sender, EventArgs e)
        {

        }

        private async void btnSearch_Click(object sender, EventArgs e)
        {
            string symptom = txtSymptom.Text.Trim();
            if (string.IsNullOrEmpty(symptom))
            {
                MessageBox.Show("Por favor ingrese un síntoma para buscar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            lblStatus.Text = "Buscando medicamentos...";
            btnSearch.Enabled = false;
            dgvResults.Rows.Clear();

            try
            {
                var drugs = await SearchMedicationsAsync(symptom);
                if (drugs.Count > 0)
                {
                    foreach (var drug in drugs)
                    {
                        dgvResults.Rows.Add(drug.Name, drug.Description);
                    }
                    lblStatus.Text = "Medicamentos encontrados: " + drugs.Count;
                }
                else
                {
                    lblStatus.Text = "No se encontraron medicamentos para ese síntoma.";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al buscar medicamentos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblStatus.Text = "Error en la búsqueda";
            }
            finally
            {
                btnSearch.Enabled = true;
            }
        }

        private async Task<List<DrugInfo>> SearchMedicationsAsync(string symptom)
        {
            string queryParam = Uri.EscapeDataString(symptom);
            string apiUrl = $"https://api.fda.gov/drug/label.json?search=indications_and_usage:{queryParam}&limit=10";

            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(apiUrl);
                response.EnsureSuccessStatusCode();
                var jsonString = await response.Content.ReadAsStringAsync();

                var root = JsonSerializer.Deserialize<OpenFdaResponse>(jsonString, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true,
                });

                List<DrugInfo> list = new List<DrugInfo>();
                if (root?.Results != null)
                {
                    foreach (var item in root.Results)
                    {
                        string drugName = "Desconocido";
                        if (item.Openfda != null && item.Openfda.BrandName != null && item.Openfda.BrandName.Length > 0)
                        {
                            drugName = string.Join(", ", item.Openfda.BrandName);
                        }
                        string desc = item.IndicationsAndUsage != null && item.IndicationsAndUsage.Length > 0
                            ? item.IndicationsAndUsage[0]
                            : "No descripción";

                        list.Add(new DrugInfo() { Name = drugName, Description = desc });
                    }
                }
                return list;
            }
        }

        // Classes for JSON deserialization
        public class OpenFdaResponse
        {
            [JsonPropertyName("results")]
            public DrugLabelResult[] Results { get; set; }
        }

        public class DrugLabelResult
        {
            [JsonPropertyName("indications_and_usage")]
            public string[] IndicationsAndUsage { get; set; }

            [JsonPropertyName("openfda")]
            public OpenFdaInfo Openfda { get; set; }
        }

        public class OpenFdaInfo
        {
            [JsonPropertyName("brand_name")]
            public string[] BrandName { get; set; }
        }

        public class DrugInfo
        {
            public string Name { get; set; }
            public string Description { get; set; }
        }
        private void Tusalud_Load(object sender, EventArgs e)
        {

        }

        private void dgvResults_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

    



