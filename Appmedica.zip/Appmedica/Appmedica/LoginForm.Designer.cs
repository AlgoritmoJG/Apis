﻿namespace Appmedica
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnLogin = new Button();
            lblMessage = new Label();
            txtUser = new TextBox();
            txtPass = new TextBox();
            lblPass = new Label();
            lblUser = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            SuspendLayout();
            // 
            // btnLogin
            // 
            btnLogin.BackColor = Color.FromArgb(192, 255, 255);
            btnLogin.Location = new Point(203, 263);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(161, 84);
            btnLogin.TabIndex = 4;
            btnLogin.Text = "Login";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            // 
            // lblMessage
            // 
            lblMessage.AutoSize = true;
            lblMessage.Location = new Point(240, 18);
            lblMessage.Name = "lblMessage";
            lblMessage.Size = new Size(95, 20);
            lblMessage.TabIndex = 5;
            lblMessage.Text = "Bienvenido!!!";
            lblMessage.Click += lblMessage_Click;
            // 
            // txtUser
            // 
            txtUser.Location = new Point(170, 64);
            txtUser.Name = "txtUser";
            txtUser.Size = new Size(259, 27);
            txtUser.TabIndex = 1;
            txtUser.TextChanged += txtUser_TextChanged;
            // 
            // txtPass
            // 
            txtPass.Location = new Point(169, 144);
            txtPass.Name = "txtPass";
            txtPass.Size = new Size(260, 27);
            txtPass.TabIndex = 3;
            txtPass.TextChanged += txtPass_TextChanged;
            // 
            // lblPass
            // 
            lblPass.AutoSize = true;
            lblPass.Location = new Point(120, 107);
            lblPass.Name = "lblPass";
            lblPass.Size = new Size(83, 20);
            lblPass.TabIndex = 2;
            lblPass.Text = "Contrasena";
            lblPass.Click += lblPass_Click;
            // 
            // lblUser
            // 
            lblUser.AutoSize = true;
            lblUser.Location = new Point(120, 41);
            lblUser.Name = "lblUser";
            lblUser.Size = new Size(59, 20);
            lblUser.TabIndex = 0;
            lblUser.Text = "Usuario";
            lblUser.Click += lblUser_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(192, 255, 255);
            button1.Location = new Point(12, 233);
            button1.Name = "button1";
            button1.Size = new Size(98, 76);
            button1.TabIndex = 6;
            button1.Text = "Asistente Virtual";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(192, 255, 255);
            button2.Location = new Point(428, 241);
            button2.Name = "button2";
            button2.Size = new Size(110, 68);
            button2.TabIndex = 7;
            button2.Text = "Emergencia";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Red;
            button3.Location = new Point(486, 12);
            button3.Name = "button3";
            button3.Size = new Size(63, 39);
            button3.TabIndex = 8;
            button3.Text = "Salir";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.interior;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(561, 378);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(lblMessage);
            Controls.Add(btnLogin);
            Controls.Add(txtPass);
            Controls.Add(lblPass);
            Controls.Add(txtUser);
            Controls.Add(lblUser);
            Name = "LoginForm";
            Text = "LoginForm";
            Load += LoginForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnLogin;
        private Label lblMessage;
        private TextBox txtUser;
        private TextBox txtPass;
        private Label lblPass;
        private Label lblUser;
        private Button button1;
        private Button button2;
        private Button button3;
    }
}