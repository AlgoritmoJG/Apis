﻿namespace Appmedica
{
    partial class AskForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            button1 = new Button();
            lblRespuesta = new Label();
            panelRespuesta = new Panel();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            button2 = new Button();
            button3 = new Button();
            panelRespuesta.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Location = new Point(12, 65);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(266, 27);
            textBox1.TabIndex = 0;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // button1
            // 
            button1.Location = new Point(70, 117);
            button1.Name = "button1";
            button1.Size = new Size(128, 68);
            button1.TabIndex = 1;
            button1.Text = "Consultar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // lblRespuesta
            // 
            lblRespuesta.AutoSize = true;
            lblRespuesta.Location = new Point(15, 14);
            lblRespuesta.Name = "lblRespuesta";
            lblRespuesta.Size = new Size(69, 20);
            lblRespuesta.TabIndex = 2;
            lblRespuesta.Text = "Asistente";
            lblRespuesta.Click += lblRespuesta_Click;
            // 
            // panelRespuesta
            // 
            panelRespuesta.AutoScroll = true;
            panelRespuesta.Controls.Add(lblRespuesta);
            panelRespuesta.Location = new Point(343, 12);
            panelRespuesta.Name = "panelRespuesta";
            panelRespuesta.Size = new Size(445, 426);
            panelRespuesta.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(70, 26);
            label1.Name = "label1";
            label1.Size = new Size(144, 20);
            label1.TabIndex = 4;
            label1.Text = "Realiza una consulta";
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = Properties.Resources.WhatsApp_Image_2025_05_09_at_7_41_00_PM__1_;
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(56, 217);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(158, 154);
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(192, 255, 255);
            button2.Location = new Point(22, 386);
            button2.Name = "button2";
            button2.Size = new Size(101, 52);
            button2.TabIndex = 6;
            button2.Text = "Volver";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(185, 386);
            button3.Name = "button3";
            button3.Size = new Size(103, 52);
            button3.TabIndex = 7;
            button3.Text = "Guardar Resultado";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // AskForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.interior;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Controls.Add(panelRespuesta);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Name = "AskForm";
            Text = "AskForm";
            Load += AskForm_Load;
            panelRespuesta.ResumeLayout(false);
            panelRespuesta.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private Button button1;
        private Label lblRespuesta;
        private Panel panelRespuesta;
        private Label label1;
        private PictureBox pictureBox1;
        private Button button2;
        private Button button3;
    }
}