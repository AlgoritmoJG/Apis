﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;

namespace Appmedica
{
    public partial class AskForm : Form
    {
        private readonly string apiKey = "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";

        public AskForm()
        {
            InitializeComponent();
            lblRespuesta.MaximumSize = new Size(panelRespuesta.Width - 10, 0);
            // Alinear el texto a la izquierda y arriba
            lblRespuesta.TextAlign = ContentAlignment.TopLeft;
            // Registrar el evento click del botón

        }
        private void lblRespuesta_Click(object sender, EventArgs e)
        {

        }

        private void AskForm_Load(object sender, EventArgs e)
        {

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private async void button1_Click(object sender, EventArgs e)
        {
            string pregunta = textBox1.Text.Trim();
            if (string.IsNullOrEmpty(pregunta))
            {
                MessageBox.Show("Por favor ingrese una pregunta.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            lblRespuesta.Text = "Consultando...";
            button1.Enabled = false;

            try
            {
                string respuesta = await ConsultarGroqApiAsync(pregunta);
                lblRespuesta.Text = respuesta ?? "No se recibió respuesta de la API.";

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al consultar la API: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblRespuesta.Text = "Error al obtener respuesta.";
            }
            finally
            {
                button1.Enabled = true;
            }
        }
        private async Task<string> ConsultarGroqApiAsync(string pregunta)
        {
            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer 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");

                var requestBody = new
                {
                    model = "meta-llama/llama-4-scout-17b-16e-instruct", // Ajusta el modelo si es necesario
                    messages = new[]
                    {
                        new { role = "user", content = pregunta }
                    },
                    temperature = 1,
                    max_completion_tokens = 1024,
                    top_p = 1,
                    stream = false,
                    stop = (string)null
                };

                var json = JsonSerializer.Serialize(requestBody);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var url = "https://api.groq.com/openai/v1/chat/completions";

                HttpResponseMessage response = await client.PostAsync(url, content);
                response.EnsureSuccessStatusCode();

                string responseContent = await response.Content.ReadAsStringAsync();

                using (JsonDocument doc = JsonDocument.Parse(responseContent))
                {
                    return doc.RootElement
                        .GetProperty("choices")[0]
                        .GetProperty("message")
                        .GetProperty("content")
                        .GetString();
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener el texto del Label
                string textoAGuardar = lblRespuesta.Text;

                // Ruta de la carpeta destino
                string carpetaDestino = @"C:\Users\THING\Desktop\ProyectoApi\Appmedica\Datosguardados";

                // Crear la carpeta si no existe
                if (!Directory.Exists(carpetaDestino))
                {
                    Directory.CreateDirectory(carpetaDestino);
                }

                // Crear un nombre de archivo único con la fecha y hora actual
                string nombreArchivo = "datos_guardados_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".txt";
                string rutaArchivo = Path.Combine(carpetaDestino, nombreArchivo);

                // Guardar el texto en el nuevo archivo
                System.IO.File.WriteAllText(rutaArchivo, textoAGuardar);

                // Mostrar mensaje de éxito
                MessageBox.Show("Información guardada correctamente en " + rutaArchivo,
                                "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                // Mostrar mensaje de error
                MessageBox.Show("Error al guardar la información: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

   



    




        

        //public AskForm()
        //{
        //    InitializeComponent();
        //    button1.Click += Button1_Click;
        //}

       
            

      


